# DevOps-Python

Dependency:
1)  flask
2)  pytest

For running app:
python app/main.py

For runnning UTs:
pytest tests/test_main.py
